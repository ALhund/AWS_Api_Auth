const AWS = require('aws-sdk');
AWS.config.update({
    region: 'ap-northeast-1'
})
const util = require('../utils/util');
const bcrypt = require('bcryptjs');
const auth = require('../utils/auth');

const dynamodb  = new AWS.DynamoDB.DocumentClient();
const userTable = 'vry-users';

async function login(user)  {
    const username = user.username;
    const password = user.password;
    if (!user || !username || !password) {
        return util.buildResponse(401,{
            messeage: 'username&password are requird'
        })
    }

    const dynamoUser = await getUser(username);
    if (!dynamoUser || !dynamoUser.password) {
        return util.buildResponse(403,{ messeage: 'user dose not status'});
     }
    
     if (!bcrypt.compareSync(password,dynamoUser.password)) {
         return util.buildResponse(403, {messaseg: 'password is jncorect'});
     }
     const userInfo = {
         username: dynamoUser.username,
         name: dynamoUser.name
     }
     const token = auth.generateToken(userInfo)
     const response = {
        user: userInfo,
        token: token

    }
    return util.buildResponse(200, response);  
}

async function getUser(username){
    const parse = {
        TableName: userTable,
        Key: {
            username: username
        }
    }

    return await dynamodb.get(parse).promise().then(response => {
        return   response.Item;
    },error => {
        console.error('There is an error: ',error);
    })
}

module.exports.login = login;

